import { PublicKey } from '@solana/web3.js';
import BN from 'bn.js';
import { NexumProfile, NexumDispute } from './types';
import { findProfilePDA, findDisputePDA } from './utils';
import type { NexumClient } from './client';

// ── ProfileManager ────────────────────────────────────────────────────────────

export class ProfileManager {
  constructor(private client: NexumClient) {}

  async fetch(owner: PublicKey): Promise<NexumProfile | null> {
    try {
      const [profilePDA] = findProfilePDA(owner);
      const info = await this.client.connection.getAccountInfo(profilePDA);
      if (!info) return null;
      return this.deserialize(info.data);
    } catch {
      return null;
    }
  }

  async exists(owner: PublicKey): Promise<boolean> {
    const profile = await this.fetch(owner);
    return profile !== null;
  }

  private deserialize(data: Buffer): NexumProfile {
    let offset = 8; // skip discriminator

    const owner = new PublicKey(data.slice(offset, offset + 32)); offset += 32;

    const usernameLen = data.readUInt32LE(offset); offset += 4;
    const username = data.slice(offset, offset + usernameLen).toString('utf8'); offset += usernameLen;

    const skillsLen = data.readUInt32LE(offset); offset += 4;
    const skills = data.slice(offset, offset + skillsLen).toString('utf8'); offset += skillsLen;

    const reputation     = new BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const tasksCompleted = new BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const tasksCreated   = new BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const sbtLevel = data[offset]; offset += 1;
    const bump = data[offset];

    return { owner, username, skills, reputation, tasksCompleted, tasksCreated, sbtLevel, bump };
  }
}

// ── DisputeManager ────────────────────────────────────────────────────────────

export class DisputeManager {
  constructor(private client: NexumClient) {}

  async fetch(taskId: number): Promise<NexumDispute | null> {
    try {
      const [disputePDA] = findDisputePDA(taskId);
      const info = await this.client.connection.getAccountInfo(disputePDA);
      if (!info) return null;
      return this.deserialize(info.data);
    } catch {
      return null;
    }
  }

  async isDisputed(taskId: number): Promise<boolean> {
    const dispute = await this.fetch(taskId);
    return dispute !== null && !dispute.resolved;
  }

  private deserialize(data: Buffer): NexumDispute {
    let offset = 8; // skip discriminator

    const taskId   = new BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const openedBy = new PublicKey(data.slice(offset, offset + 32)); offset += 32;

    const reasonLen = data.readUInt32LE(offset); offset += 4;
    const reason = data.slice(offset, offset + reasonLen).toString('utf8'); offset += reasonLen;

    const resolved = data[offset] === 1; offset += 1;
    const bump = data[offset];

    return { taskId, openedBy, reason, resolved, bump };
  }
}
