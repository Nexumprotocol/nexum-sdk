import {
  Connection,
  PublicKey,
  clusterApiUrl,
  Commitment,
} from '@solana/web3.js';
import * as anchor from '@coral-xyz/anchor';
import { NexumConfig, Network, NexumTask, NexumProfile, NexumDispute, TaskFilter, TaskStatus } from './types';
import { NEXUM_PROGRAM_ID, NEXUM_DEVNET_RPC, NEXUM_MAINNET_RPC } from './constants';
import { findTaskPDA, findProfilePDA, findDisputePDA } from './utils';
import { TaskManager } from './tasks';
import { ProfileManager } from './profile';
import { DisputeManager } from './dispute';

export class NexumClient {
  public readonly connection:   Connection;
  public readonly programId:    PublicKey;
  public readonly network:      Network;
  public readonly tasks:        TaskManager;
  public readonly profiles:     ProfileManager;
  public readonly disputes:     DisputeManager;

  private program: anchor.Program | null = null;

  constructor(config: NexumConfig) {
    this.network   = config.network;
    this.programId = NEXUM_PROGRAM_ID;

    const rpcUrl = config.rpcUrl
      ?? (config.network === Network.Mainnet ? NEXUM_MAINNET_RPC : NEXUM_DEVNET_RPC);

    const commitment: Commitment = config.commitment ?? 'confirmed';
    this.connection = new Connection(rpcUrl, commitment);

    this.tasks    = new TaskManager(this);
    this.profiles = new ProfileManager(this);
    this.disputes = new DisputeManager(this);
  }

  // ── Factory ────────────────────────────────────────────────────────────────

  static devnet(rpcUrl?: string): NexumClient {
    return new NexumClient({ network: Network.Devnet, rpcUrl });
  }

  static mainnet(rpcUrl?: string): NexumClient {
    return new NexumClient({ network: Network.Mainnet, rpcUrl });
  }

  // ── Wallet connection ──────────────────────────────────────────────────────

  withWallet(wallet: anchor.Wallet): NexumClientWithWallet {
    return new NexumClientWithWallet(this, wallet);
  }

  // ── Read-only queries ──────────────────────────────────────────────────────

  async getTask(taskId: number): Promise<NexumTask | null> {
    return this.tasks.fetch(taskId);
  }

  async getAllTasks(filter?: TaskFilter): Promise<NexumTask[]> {
    return this.tasks.fetchAll(filter);
  }

  async getProfile(owner: PublicKey): Promise<NexumProfile | null> {
    return this.profiles.fetch(owner);
  }

  async getDispute(taskId: number): Promise<NexumDispute | null> {
    return this.disputes.fetch(taskId);
  }

  async getEscrowBalance(taskId: number): Promise<number> {
    return this.tasks.getEscrowBalance(taskId);
  }

  async getTVL(): Promise<number> {
    return this.tasks.getTotalTVL();
  }

  // ── Utility ────────────────────────────────────────────────────────────────

  isDevnet(): boolean {
    return this.network === Network.Devnet;
  }

  explorerUrl(address: string, type: 'address' | 'tx' = 'address'): string {
    const cluster = this.isDevnet() ? '?cluster=devnet' : '';
    return `https://explorer.solana.com/${type}/${address}${cluster}`;
  }
}

// ── Wallet-connected client (for write operations) ─────────────────────────

export class NexumClientWithWallet extends NexumClient {
  public readonly wallet: anchor.Wallet;
  public readonly provider: anchor.AnchorProvider;

  constructor(base: NexumClient, wallet: anchor.Wallet) {
    super({ network: base.network });
    this.wallet   = wallet;
    this.provider = new anchor.AnchorProvider(base.connection, wallet, {
      commitment: 'confirmed',
    });
  }

  get publicKey(): PublicKey {
    return this.wallet.publicKey;
  }
}
