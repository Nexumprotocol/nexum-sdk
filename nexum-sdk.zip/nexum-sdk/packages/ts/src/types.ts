import { PublicKey } from '@solana/web3.js';
import BN from 'bn.js';

// ── Enums ────────────────────────────────────────────────────────────────────

export enum TaskStatus {
  Open       = 'open',
  InProgress = 'inProgress',
  Completed  = 'completed',
  Disputed   = 'disputed',
  Cancelled  = 'cancelled',
}

export enum Network {
  Devnet  = 'devnet',
  Mainnet = 'mainnet-beta',
  Local   = 'localnet',
}

// ── On-chain account shapes ───────────────────────────────────────────────────

export interface NexumTask {
  taskId:         BN;
  creator:        PublicKey;
  title:          string;
  description:    string;
  requiredSkills: string;
  rewardLamports: BN;
  deadlineUnix:   BN;
  status:         TaskStatus;
  worker:         PublicKey | null;
  bump:           number;
  escrowBump:     number;
}

export interface NexumProfile {
  owner:          PublicKey;
  username:       string;
  skills:         string;
  reputation:     BN;
  tasksCompleted: BN;
  tasksCreated:   BN;
  sbtLevel:       number;
  bump:           number;
}

export interface NexumDispute {
  taskId:   BN;
  openedBy: PublicKey;
  reason:   string;
  resolved: boolean;
  bump:     number;
}

// ── Input types ───────────────────────────────────────────────────────────────

export interface CreateTaskInput {
  taskId:         number | BN;
  title:          string;       // max 80 chars
  description:    string;       // max 500 chars
  requiredSkills: string;       // max 200 chars, comma-separated
  rewardSol:      number;       // in SOL (converted to lamports internally)
  deadlineDays:   number;       // days from now
}

export interface CreateProfileInput {
  username: string;   // max 32 chars
  skills:   string;   // max 200 chars, comma-separated
}

export interface OpenDisputeInput {
  taskId: number | BN;
  reason: string;     // max 300 chars
}

export interface ResolveDisputeInput {
  taskId:       number | BN;
  favourWorker: boolean;
}

// ── Query filters ─────────────────────────────────────────────────────────────

export interface TaskFilter {
  status?:  TaskStatus;
  creator?: PublicKey;
  worker?:  PublicKey;
}

// ── Events ────────────────────────────────────────────────────────────────────

export interface NexumEvent {
  type:      'TaskCreated' | 'TaskCompleted' | 'TaskApplied' | 'DisputeOpened' | 'DisputeResolved' | 'ProfileCreated';
  signature: string;
  slot:      number;
  data:      Record<string, unknown>;
}

// ── SDK Config ────────────────────────────────────────────────────────────────

export interface NexumConfig {
  network:    Network;
  rpcUrl?:    string;       // override default RPC
  commitment?: 'processed' | 'confirmed' | 'finalized';
}
