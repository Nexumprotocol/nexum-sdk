import time
import struct
from typing import Tuple
from .constants import (
    NEXUM_PROGRAM_ID, SEEDS, LAMPORTS_PER_SOL,
    SBT_LEVELS, SBT_THRESHOLDS, PLATFORM_FEE_BPS
)

# ── PDA derivation (requires solders or solana-py) ────────────────────────────

def find_task_pda(task_id: int) -> Tuple[str, int]:
    """Derive Task PDA for a given task_id."""
    try:
        from solders.pubkey import Pubkey
        id_bytes = struct.pack('<Q', task_id)
        return Pubkey.find_program_address(
            [SEEDS['task'], id_bytes],
            Pubkey.from_string(NEXUM_PROGRAM_ID)
        )
    except ImportError:
        raise ImportError("Install solders: pip install solders")


def find_escrow_pda(task_id: int) -> Tuple[str, int]:
    try:
        from solders.pubkey import Pubkey
        id_bytes = struct.pack('<Q', task_id)
        return Pubkey.find_program_address(
            [SEEDS['escrow'], id_bytes],
            Pubkey.from_string(NEXUM_PROGRAM_ID)
        )
    except ImportError:
        raise ImportError("Install solders: pip install solders")


def find_profile_pda(owner: str) -> Tuple[str, int]:
    try:
        from solders.pubkey import Pubkey
        owner_key = Pubkey.from_string(owner)
        return Pubkey.find_program_address(
            [SEEDS['profile'], bytes(owner_key)],
            Pubkey.from_string(NEXUM_PROGRAM_ID)
        )
    except ImportError:
        raise ImportError("Install solders: pip install solders")


def find_dispute_pda(task_id: int) -> Tuple[str, int]:
    try:
        from solders.pubkey import Pubkey
        id_bytes = struct.pack('<Q', task_id)
        return Pubkey.find_program_address(
            [SEEDS['dispute'], id_bytes],
            Pubkey.from_string(NEXUM_PROGRAM_ID)
        )
    except ImportError:
        raise ImportError("Install solders: pip install solders")


# ── SOL / Lamport conversions ─────────────────────────────────────────────────

def sol_to_lamports(sol: float) -> int:
    return int(sol * LAMPORTS_PER_SOL)


def lamports_to_sol(lamports: int) -> float:
    return lamports / LAMPORTS_PER_SOL


def calculate_fee(reward_lamports: int) -> dict:
    fee    = reward_lamports * PLATFORM_FEE_BPS // 10_000
    payout = reward_lamports - fee
    return {"fee": fee, "payout": payout}


# ── SBT helpers ───────────────────────────────────────────────────────────────

def get_sbt_level(tasks_completed: int) -> int:
    for i in range(len(SBT_THRESHOLDS) - 1, -1, -1):
        if tasks_completed >= SBT_THRESHOLDS[i]:
            return i
    return 0


def get_sbt_label(level: int) -> str:
    return SBT_LEVELS.get(level, "Unknown")


def get_next_sbt_threshold(tasks_completed: int) -> int | None:
    for threshold in SBT_THRESHOLDS:
        if tasks_completed < threshold:
            return threshold
    return None


# ── Time helpers ──────────────────────────────────────────────────────────────

def days_from_now(days: int) -> int:
    return int(time.time()) + days * 86_400


def days_left(deadline_unix: int) -> int:
    now = int(time.time())
    return max(0, (deadline_unix - now) // 86_400)


# ── Address helpers ───────────────────────────────────────────────────────────

def short_address(pubkey: str) -> str:
    return f"{pubkey[:4]}...{pubkey[-4:]}"


def explorer_url(value: str, type_: str = "address", cluster: str = "devnet") -> str:
    base    = "https://explorer.solana.com"
    cluster_param = f"?cluster={cluster}" if cluster != "mainnet-beta" else ""
    return f"{base}/{type_}/{value}{cluster_param}"
