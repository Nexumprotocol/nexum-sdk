import struct
import asyncio
from typing import Optional, List
import httpx

from .constants import NEXUM_PROGRAM_ID, NEXUM_DEVNET_RPC, NEXUM_MAINNET_RPC, LAMPORTS_PER_SOL
from .types import NexumTask, NexumProfile, NexumDispute, TaskStatus, Network, TaskFilter
from .utils import find_task_pda, find_profile_pda, find_dispute_pda, lamports_to_sol


class NexumClient:
    """
    Read-only client for NEXUM Protocol.
    For write operations, use the Anchor program directly or TypeScript SDK.
    """

    def __init__(self, network: Network = Network.DEVNET, rpc_url: str = None):
        self.network    = network
        self.program_id = NEXUM_PROGRAM_ID
        self.rpc_url    = rpc_url or (
            NEXUM_DEVNET_RPC if network == Network.DEVNET else NEXUM_MAINNET_RPC
        )

    # ── Factory ────────────────────────────────────────────────────────────

    @classmethod
    def devnet(cls, rpc_url: str = None) -> "NexumClient":
        return cls(Network.DEVNET, rpc_url)

    @classmethod
    def mainnet(cls, rpc_url: str = None) -> "NexumClient":
        return cls(Network.MAINNET, rpc_url)

    # ── RPC helpers ────────────────────────────────────────────────────────

    async def _rpc(self, method: str, params: list) -> dict:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(self.rpc_url, json={
                "jsonrpc": "2.0", "id": 1, "method": method, "params": params
            })
            data = resp.json()
            return data.get("result")

    async def _get_account(self, address: str) -> Optional[bytes]:
        result = await self._rpc("getAccountInfo", [
            address, {"encoding": "base64", "commitment": "confirmed"}
        ])
        if not result or not result.get("value"):
            return None
        import base64
        return base64.b64decode(result["value"]["data"][0])

    # ── Task queries ───────────────────────────────────────────────────────

    async def get_task(self, task_id: int) -> Optional[NexumTask]:
        try:
            pda, _ = find_task_pda(task_id)
            data   = await self._get_account(str(pda))
            if not data:
                return None
            return self._deserialize_task(data)
        except Exception:
            return None

    async def get_all_tasks(self, filter_: TaskFilter = None) -> List[NexumTask]:
        try:
            result = await self._rpc("getProgramAccounts", [
                self.program_id,
                {
                    "encoding": "base64",
                    "commitment": "confirmed",
                    "filters": [{"dataSize": 892}]
                }
            ])
            if not result:
                return []

            tasks = []
            for item in result:
                try:
                    import base64
                    data = base64.b64decode(item["account"]["data"][0])
                    task = self._deserialize_task(data)
                    tasks.append(task)
                except Exception:
                    continue

            if filter_:
                if filter_.status:
                    tasks = [t for t in tasks if t.status == filter_.status]
                if filter_.creator:
                    tasks = [t for t in tasks if t.creator == filter_.creator]
                if filter_.worker:
                    tasks = [t for t in tasks if t.worker == filter_.worker]

            return tasks
        except Exception:
            return []

    async def get_open_tasks(self) -> List[NexumTask]:
        return await self.get_all_tasks(TaskFilter(status=TaskStatus.OPEN))

    async def get_tvl(self) -> float:
        tasks = await self.get_all_tasks(TaskFilter(status=TaskStatus.OPEN))
        in_progress = await self.get_all_tasks(TaskFilter(status=TaskStatus.IN_PROGRESS))
        total = sum(t.reward_sol for t in tasks + in_progress)
        return total

    # ── Profile queries ────────────────────────────────────────────────────

    async def get_profile(self, owner: str) -> Optional[NexumProfile]:
        try:
            pda, _ = find_profile_pda(owner)
            data   = await self._get_account(str(pda))
            if not data:
                return None
            return self._deserialize_profile(data)
        except Exception:
            return None

    # ── Dispute queries ────────────────────────────────────────────────────

    async def get_dispute(self, task_id: int) -> Optional[NexumDispute]:
        try:
            pda, _ = find_dispute_pda(task_id)
            data   = await self._get_account(str(pda))
            if not data:
                return None
            return self._deserialize_dispute(data)
        except Exception:
            return None

    # ── Deserializers ──────────────────────────────────────────────────────

    def _deserialize_task(self, data: bytes) -> NexumTask:
        offset = 8  # skip discriminator

        task_id = struct.unpack_from('<Q', data, offset)[0]; offset += 8
        creator = self._read_pubkey(data, offset); offset += 32

        title_len = struct.unpack_from('<I', data, offset)[0]; offset += 4
        title = data[offset:offset+title_len].decode('utf-8'); offset += title_len

        desc_len = struct.unpack_from('<I', data, offset)[0]; offset += 4
        description = data[offset:offset+desc_len].decode('utf-8'); offset += desc_len

        skills_len = struct.unpack_from('<I', data, offset)[0]; offset += 4
        required_skills = data[offset:offset+skills_len].decode('utf-8'); offset += skills_len

        reward_lamports = struct.unpack_from('<Q', data, offset)[0]; offset += 8
        deadline_unix   = struct.unpack_from('<q', data, offset)[0]; offset += 8

        status_byte = data[offset]; offset += 1
        status_map  = {0: TaskStatus.OPEN, 1: TaskStatus.IN_PROGRESS, 2: TaskStatus.COMPLETED, 3: TaskStatus.DISPUTED, 4: TaskStatus.CANCELLED}
        status = status_map.get(status_byte, TaskStatus.OPEN)

        has_worker = data[offset] == 1; offset += 1
        worker = self._read_pubkey(data, offset) if has_worker else None
        if has_worker: offset += 32

        bump = data[offset]; offset += 1
        escrow_bump = data[offset]

        return NexumTask(task_id, creator, title, description, required_skills, reward_lamports, deadline_unix, status, worker, bump, escrow_bump)

    def _deserialize_profile(self, data: bytes) -> NexumProfile:
        offset = 8
        owner = self._read_pubkey(data, offset); offset += 32

        un_len = struct.unpack_from('<I', data, offset)[0]; offset += 4
        username = data[offset:offset+un_len].decode('utf-8'); offset += un_len

        sk_len = struct.unpack_from('<I', data, offset)[0]; offset += 4
        skills = data[offset:offset+sk_len].decode('utf-8'); offset += sk_len

        reputation     = struct.unpack_from('<Q', data, offset)[0]; offset += 8
        tasks_completed = struct.unpack_from('<Q', data, offset)[0]; offset += 8
        tasks_created  = struct.unpack_from('<Q', data, offset)[0]; offset += 8
        sbt_level = data[offset]; offset += 1
        bump = data[offset]

        return NexumProfile(owner, username, skills, reputation, tasks_completed, tasks_created, sbt_level, bump)

    def _deserialize_dispute(self, data: bytes) -> NexumDispute:
        offset = 8
        task_id   = struct.unpack_from('<Q', data, offset)[0]; offset += 8
        opened_by = self._read_pubkey(data, offset); offset += 32

        r_len  = struct.unpack_from('<I', data, offset)[0]; offset += 4
        reason = data[offset:offset+r_len].decode('utf-8'); offset += r_len

        resolved = data[offset] == 1; offset += 1
        bump = data[offset]

        return NexumDispute(task_id, opened_by, reason, resolved, bump)

    def _read_pubkey(self, data: bytes, offset: int) -> str:
        import base58
        return base58.b58encode(data[offset:offset+32]).decode('utf-8')

    # ── Sync wrappers ──────────────────────────────────────────────────────

    def get_task_sync(self, task_id: int) -> Optional[NexumTask]:
        return asyncio.run(self.get_task(task_id))

    def get_all_tasks_sync(self, filter_: TaskFilter = None) -> List[NexumTask]:
        return asyncio.run(self.get_all_tasks(filter_))

    def get_tvl_sync(self) -> float:
        return asyncio.run(self.get_tvl())
