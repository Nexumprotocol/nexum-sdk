"""
nexum-sdk — Official Python SDK for NEXUM Protocol on Solana
"""

from .client import NexumClient
from .types import (
    NexumTask,
    NexumProfile,
    NexumDispute,
    TaskStatus,
    Network,
    CreateTaskInput,
    CreateProfileInput,
)
from .constants import (
    NEXUM_PROGRAM_ID,
    NEXUM_DEVNET_RPC,
    NEXUM_MAINNET_RPC,
    PLATFORM_FEE_BPS,
    SBT_LEVELS,
    SBT_THRESHOLDS,
)
from .utils import (
    find_task_pda,
    find_escrow_pda,
    find_profile_pda,
    find_dispute_pda,
    sol_to_lamports,
    lamports_to_sol,
    get_sbt_level,
    get_sbt_label,
    days_from_now,
    short_address,
)

__version__ = "0.1.0"
__all__ = [
    "NexumClient",
    "NexumTask", "NexumProfile", "NexumDispute",
    "TaskStatus", "Network",
    "CreateTaskInput", "CreateProfileInput",
    "NEXUM_PROGRAM_ID", "NEXUM_DEVNET_RPC", "NEXUM_MAINNET_RPC",
    "PLATFORM_FEE_BPS", "SBT_LEVELS", "SBT_THRESHOLDS",
    "find_task_pda", "find_escrow_pda", "find_profile_pda", "find_dispute_pda",
    "sol_to_lamports", "lamports_to_sol",
    "get_sbt_level", "get_sbt_label",
    "days_from_now", "short_address",
]
