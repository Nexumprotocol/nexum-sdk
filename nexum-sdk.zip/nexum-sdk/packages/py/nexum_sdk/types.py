from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class TaskStatus(str, Enum):
    OPEN        = "open"
    IN_PROGRESS = "inProgress"
    COMPLETED   = "completed"
    DISPUTED    = "disputed"
    CANCELLED   = "cancelled"


class Network(str, Enum):
    DEVNET  = "devnet"
    MAINNET = "mainnet-beta"
    LOCAL   = "localnet"


@dataclass
class NexumTask:
    task_id:         int
    creator:         str
    title:           str
    description:     str
    required_skills: str
    reward_lamports: int
    deadline_unix:   int
    status:          TaskStatus
    worker:          Optional[str]
    bump:            int
    escrow_bump:     int

    @property
    def reward_sol(self) -> float:
        from .constants import LAMPORTS_PER_SOL
        return self.reward_lamports / LAMPORTS_PER_SOL

    @property
    def skills_list(self) -> list[str]:
        return [s.strip() for s in self.required_skills.split(',')]


@dataclass
class NexumProfile:
    owner:           str
    username:        str
    skills:          str
    reputation:      int
    tasks_completed: int
    tasks_created:   int
    sbt_level:       int
    bump:            int

    @property
    def sbt_label(self) -> str:
        from .constants import SBT_LEVELS
        return SBT_LEVELS.get(self.sbt_level, "Unknown")

    @property
    def skills_list(self) -> list[str]:
        return [s.strip() for s in self.skills.split(',')]


@dataclass
class NexumDispute:
    task_id:   int
    opened_by: str
    reason:    str
    resolved:  bool
    bump:      int


@dataclass
class CreateTaskInput:
    task_id:         int
    title:           str        # max 80 chars
    description:     str        # max 500 chars
    required_skills: str        # max 200 chars, comma-separated
    reward_sol:      float      # in SOL
    deadline_days:   int        # days from now


@dataclass
class CreateProfileInput:
    username: str   # max 32 chars
    skills:   str   # max 200 chars


@dataclass
class TaskFilter:
    status:  Optional[TaskStatus] = None
    creator: Optional[str]        = None
    worker:  Optional[str]        = None
