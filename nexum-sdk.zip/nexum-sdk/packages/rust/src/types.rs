use solana_sdk::pubkey::Pubkey;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TaskStatus {
    Open,
    InProgress,
    Completed,
    Disputed,
    Cancelled,
}

impl TaskStatus {
    pub fn from_u8(v: u8) -> Self {
        match v {
            0 => Self::Open,
            1 => Self::InProgress,
            2 => Self::Completed,
            3 => Self::Disputed,
            4 => Self::Cancelled,
            _ => Self::Open,
        }
    }
}

#[derive(Debug, Clone)]
pub enum Network {
    Devnet,
    Mainnet,
}

#[derive(Debug, Clone)]
pub struct NexumTask {
    pub task_id:         u64,
    pub creator:         Pubkey,
    pub title:           String,
    pub description:     String,
    pub required_skills: String,
    pub reward_lamports: u64,
    pub deadline_unix:   i64,
    pub status:          TaskStatus,
    pub worker:          Option<Pubkey>,
    pub bump:            u8,
    pub escrow_bump:     u8,
}

impl NexumTask {
    pub fn reward_sol(&self) -> f64 {
        self.reward_lamports as f64 / 1_000_000_000.0
    }
    pub fn skills_vec(&self) -> Vec<&str> {
        self.required_skills.split(',').map(str::trim).collect()
    }
}

#[derive(Debug, Clone)]
pub struct NexumProfile {
    pub owner:           Pubkey,
    pub username:        String,
    pub skills:          String,
    pub reputation:      u64,
    pub tasks_completed: u64,
    pub tasks_created:   u64,
    pub sbt_level:       u8,
    pub bump:            u8,
}

impl NexumProfile {
    pub fn sbt_label(&self) -> &'static str {
        crate::constants::SBT_LABELS
            .get(self.sbt_level as usize)
            .copied()
            .unwrap_or("Unknown")
    }
}

#[derive(Debug, Clone)]
pub struct NexumDispute {
    pub task_id:   u64,
    pub opened_by: Pubkey,
    pub reason:    String,
    pub resolved:  bool,
    pub bump:      u8,
}

#[derive(Debug, Clone)]
pub struct TaskFilter {
    pub status:  Option<TaskStatus>,
    pub creator: Option<Pubkey>,
    pub worker:  Option<Pubkey>,
}
