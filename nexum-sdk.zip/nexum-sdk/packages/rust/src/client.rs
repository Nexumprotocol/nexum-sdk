use solana_client::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey::Pubkey};
use std::str::FromStr;
use crate::{
    constants::*,
    error::NexumError,
    types::*,
    utils::*,
};

pub struct NexumClient {
    pub rpc:        RpcClient,
    pub program_id: Pubkey,
    pub network:    Network,
}

impl NexumClient {
    pub fn new(network: Network, rpc_url: Option<&str>) -> Self {
        let url = rpc_url.unwrap_or(match network {
            Network::Devnet  => NEXUM_DEVNET_RPC,
            Network::Mainnet => NEXUM_MAINNET_RPC,
        });
        Self {
            rpc:        RpcClient::new_with_commitment(url, CommitmentConfig::confirmed()),
            program_id: Pubkey::from_str(NEXUM_PROGRAM_ID).unwrap(),
            network,
        }
    }

    pub fn devnet() -> Self {
        Self::new(Network::Devnet, None)
    }

    pub fn mainnet() -> Self {
        Self::new(Network::Mainnet, None)
    }

    // ── Task queries ───────────────────────────────────────────────────────

    pub fn get_task(&self, task_id: u64) -> Result<Option<NexumTask>, NexumError> {
        let (pda, _) = find_task_pda(task_id);
        match self.rpc.get_account(&pda) {
            Ok(account) => Ok(Some(self.deserialize_task(&account.data)?)),
            Err(_)      => Ok(None),
        }
    }

    pub fn get_all_tasks(&self) -> Result<Vec<NexumTask>, NexumError> {
        use solana_client::rpc_config::{RpcProgramAccountsConfig, RpcAccountInfoConfig};
        use solana_client::rpc_filter::{RpcFilterType, Memcmp, MemcmpEncodedBytes};

        let config = RpcProgramAccountsConfig {
            filters: Some(vec![RpcFilterType::DataSize(892)]),
            account_config: RpcAccountInfoConfig {
                encoding: Some(solana_account_decoder::UiAccountEncoding::Base64),
                ..Default::default()
            },
            ..Default::default()
        };

        let accounts = self.rpc
            .get_program_accounts_with_config(&self.program_id, config)
            .map_err(|e| NexumError::Rpc(e.to_string()))?;

        let tasks = accounts
            .into_iter()
            .filter_map(|(_, acc)| self.deserialize_task(&acc.data).ok())
            .collect();

        Ok(tasks)
    }

    pub fn get_tvl(&self) -> Result<f64, NexumError> {
        let tasks = self.get_all_tasks()?;
        let tvl: u64 = tasks
            .iter()
            .filter(|t| matches!(t.status, TaskStatus::Open | TaskStatus::InProgress))
            .map(|t| t.reward_lamports)
            .sum();
        Ok(lamports_to_sol(tvl))
    }

    // ── Profile queries ────────────────────────────────────────────────────

    pub fn get_profile(&self, owner: &Pubkey) -> Result<Option<NexumProfile>, NexumError> {
        let (pda, _) = find_profile_pda(owner);
        match self.rpc.get_account(&pda) {
            Ok(account) => Ok(Some(self.deserialize_profile(&account.data)?)),
            Err(_)      => Ok(None),
        }
    }

    // ── Deserializers ──────────────────────────────────────────────────────

    fn deserialize_task(&self, data: &[u8]) -> Result<NexumTask, NexumError> {
        if data.len() < 16 {
            return Err(NexumError::Deserialize("Data too short".into()));
        }
        let mut offset = 8usize; // skip discriminator

        let task_id = u64::from_le_bytes(data[offset..offset+8].try_into().unwrap()); offset += 8;
        let creator = Pubkey::try_from(&data[offset..offset+32]).unwrap(); offset += 32;

        let title_len = u32::from_le_bytes(data[offset..offset+4].try_into().unwrap()) as usize; offset += 4;
        let title = String::from_utf8_lossy(&data[offset..offset+title_len]).into_owned(); offset += title_len;

        let desc_len = u32::from_le_bytes(data[offset..offset+4].try_into().unwrap()) as usize; offset += 4;
        let description = String::from_utf8_lossy(&data[offset..offset+desc_len]).into_owned(); offset += desc_len;

        let sk_len = u32::from_le_bytes(data[offset..offset+4].try_into().unwrap()) as usize; offset += 4;
        let required_skills = String::from_utf8_lossy(&data[offset..offset+sk_len]).into_owned(); offset += sk_len;

        let reward_lamports = u64::from_le_bytes(data[offset..offset+8].try_into().unwrap()); offset += 8;
        let deadline_unix   = i64::from_le_bytes(data[offset..offset+8].try_into().unwrap()); offset += 8;

        let status = TaskStatus::from_u8(data[offset]); offset += 1;

        let has_worker = data[offset] == 1; offset += 1;
        let worker = if has_worker {
            let pk = Pubkey::try_from(&data[offset..offset+32]).unwrap();
            offset += 32;
            Some(pk)
        } else { None };

        let bump       = data[offset]; offset += 1;
        let escrow_bump = data[offset];

        Ok(NexumTask { task_id, creator, title, description, required_skills, reward_lamports, deadline_unix, status, worker, bump, escrow_bump })
    }

    fn deserialize_profile(&self, data: &[u8]) -> Result<NexumProfile, NexumError> {
        let mut offset = 8usize;

        let owner = Pubkey::try_from(&data[offset..offset+32]).unwrap(); offset += 32;

        let un_len = u32::from_le_bytes(data[offset..offset+4].try_into().unwrap()) as usize; offset += 4;
        let username = String::from_utf8_lossy(&data[offset..offset+un_len]).into_owned(); offset += un_len;

        let sk_len = u32::from_le_bytes(data[offset..offset+4].try_into().unwrap()) as usize; offset += 4;
        let skills = String::from_utf8_lossy(&data[offset..offset+sk_len]).into_owned(); offset += sk_len;

        let reputation      = u64::from_le_bytes(data[offset..offset+8].try_into().unwrap()); offset += 8;
        let tasks_completed = u64::from_le_bytes(data[offset..offset+8].try_into().unwrap()); offset += 8;
        let tasks_created   = u64::from_le_bytes(data[offset..offset+8].try_into().unwrap()); offset += 8;
        let sbt_level = data[offset]; offset += 1;
        let bump = data[offset];

        Ok(NexumProfile { owner, username, skills, reputation, tasks_completed, tasks_created, sbt_level, bump })
    }
}
