//! # nexum-sdk
//!
//! Official Rust SDK for NEXUM Protocol on Solana.
//!
//! ## Quick Start
//!
//! ```rust
//! use nexum_sdk::{NexumClient, Network};
//!
//! #[tokio::main]
//! async fn main() {
//!     let client = NexumClient::devnet();
//!
//!     // Fetch a task
//!     if let Some(task) = client.get_task(1).await.unwrap() {
//!         println!("Task: {}", task.title);
//!         println!("Reward: {} SOL", task.reward_sol());
//!         println!("Status: {:?}", task.status);
//!     }
//!
//!     // Get TVL
//!     let tvl = client.get_tvl().await.unwrap();
//!     println!("Total Value Locked: {:.3} SOL", tvl);
//! }
//! ```

pub mod client;
pub mod constants;
pub mod types;
pub mod utils;
pub mod error;

pub use client::NexumClient;
pub use constants::*;
pub use types::*;
pub use utils::*;
pub use error::NexumError;
