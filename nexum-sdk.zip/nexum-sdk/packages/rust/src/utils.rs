use solana_sdk::pubkey::Pubkey;
use std::str::FromStr;
use crate::constants::*;

pub fn find_task_pda(task_id: u64) -> (Pubkey, u8) {
    let program_id = Pubkey::from_str(NEXUM_PROGRAM_ID).unwrap();
    let id_bytes   = task_id.to_le_bytes();
    Pubkey::find_program_address(&[TASK_SEED, &id_bytes], &program_id)
}

pub fn find_escrow_pda(task_id: u64) -> (Pubkey, u8) {
    let program_id = Pubkey::from_str(NEXUM_PROGRAM_ID).unwrap();
    let id_bytes   = task_id.to_le_bytes();
    Pubkey::find_program_address(&[ESCROW_SEED, &id_bytes], &program_id)
}

pub fn find_profile_pda(owner: &Pubkey) -> (Pubkey, u8) {
    let program_id = Pubkey::from_str(NEXUM_PROGRAM_ID).unwrap();
    Pubkey::find_program_address(&[PROFILE_SEED, owner.as_ref()], &program_id)
}

pub fn find_dispute_pda(task_id: u64) -> (Pubkey, u8) {
    let program_id = Pubkey::from_str(NEXUM_PROGRAM_ID).unwrap();
    let id_bytes   = task_id.to_le_bytes();
    Pubkey::find_program_address(&[DISPUTE_SEED, &id_bytes], &program_id)
}

pub fn sol_to_lamports(sol: f64) -> u64 {
    (sol * LAMPORTS_PER_SOL as f64) as u64
}

pub fn lamports_to_sol(lamports: u64) -> f64 {
    lamports as f64 / LAMPORTS_PER_SOL as f64
}

pub fn get_sbt_level(tasks_completed: u64) -> u8 {
    for (i, &threshold) in SBT_THRESHOLDS.iter().enumerate().rev() {
        if tasks_completed >= threshold {
            return i as u8;
        }
    }
    0
}

pub fn short_address(pubkey: &Pubkey) -> String {
    let s = pubkey.to_string();
    format!("{}...{}", &s[..4], &s[s.len()-4..])
}

pub fn days_from_now(days: u64) -> i64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs();
    (now + days * 86_400) as i64
}
